import { defineCloudflareConfig } from "@opennextjs/cloudflare";

// Minimal config. You can enable R2 incremental cache later if desired.
export default defineCloudflareConfig({});
